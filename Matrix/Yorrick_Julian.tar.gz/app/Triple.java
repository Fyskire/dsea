package app;

// just because java sucks
class Triple {

    double x, y, z;

    Triple (double x, double y, double z){

        this.x = x;
        this.y = y;
        this.z = z;
    }
}


